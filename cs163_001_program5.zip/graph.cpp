//Evelyn Nguyen, CS163 - 001, program#5, 03/14/25
//This file is to implement the needed functions for graph header file

#include "graph.h"

//Constructor to initialize
table::table(int size)
{
	num_shop = 0;
	max_shop = size;
	adjacency_list = new vertex[max_shop];
        for (int i =0; i < max_shop; ++ i)
	{
		adjacency_list[i].entry = nullptr;
		adjacency_list[i].head = nullptr;
	}	
}	

//Destructor to clean up memory
table::~table()
{
	for (int i =0; i < num_shop; ++i)
	{
	        if (adjacency_list[i].entry != nullptr)
			delete adjacency_list[i].entry;	
		node * current = adjacency_list[i].head;
		while (current)
		{
			node * temp = current -> next;
			delete current;
			current = temp;
		}
	}
	delete[] adjacency_list;
}	

//This function is to insert a vertex (a shop)
//Argument: const shop & to_add)
//Return: 1/0 for success/failure
int table::insert_vertex(const shop & to_add)
{
        //handle if duplicate vertex entered
	for (int i =0; i < num_shop; ++i)
	{
		if (adjacency_list[i].entry != nullptr && adjacency_list[i].entry -> compare(to_add.get_name()))
		{
			return 0;
		}	
	}

	//resize if wanting to add more than 5 shops
	if (num_shop >= max_shop)
	{
	        int old_max = max_shop;	
		max_shop *= 2;
		vertex * new_adjacency_list = new vertex[max_shop];
	        for (int i =0; i < old_max; ++i)
		{	
			new_adjacency_list[i] = adjacency_list[i];
		 
		}
		for (int i = old_max; i < max_shop; ++i)
		{
			new_adjacency_list[i].entry = nullptr;
			new_adjacency_list[i].head = nullptr;
		}
		delete[] adjacency_list;
		adjacency_list = new_adjacency_list;
	}
        //add vertex	
        int flag = 0;
        shop * temp = nullptr;	
        for (int i =0; i < max_shop; ++i)
	{
		if (adjacency_list[i].entry == nullptr)
		{
		        if (flag ==0)
			{	
				temp = new shop;
				temp -> copy_shop(to_add);
				adjacency_list[i].entry = temp;
			        adjacency_list[i].head = nullptr;	
				++ num_shop; 
				flag = 1;
			        break;	
			}	
		}
	}	
	return flag;	
}	

//This function is to insert an edge
//Argument: const string & current_vertex, const string & to_attach, int distance
//Return: 1/0 for success/failure
int table::insert_edge(const string & current_vertex, const string & to_attach, int distance)
{
	int current_idx = find_shop_index(current_vertex);
	int to_attach_idx = find_shop_index(to_attach);
	if (current_idx == -1 || to_attach_idx == -1) return 0;
        if (edge_exists(current_idx, to_attach_idx)) return 0;	
	node * new_edge = new node;
	new_edge -> adjacent = &adjacency_list[to_attach_idx];
	new_edge -> distance = distance;
	new_edge -> next = adjacency_list[current_idx].head;
	adjacency_list[current_idx].head = new_edge;
        node * reverse = new node;
	reverse -> adjacent = &adjacency_list[current_idx];
	reverse -> distance = distance;
	reverse -> next = adjacency_list[to_attach_idx].head;
	adjacency_list[to_attach_idx].head = reverse;	
	return 1;	
}

//This function is the helper function to chech if the edge is already inserted (avoid dupplication)
//Argument:
//Return: true/false for success/failure
bool table::edge_exists(int current_idx, int to_attach_idx)
{
	node * current = adjacency_list[current_idx].head;
	bool found = false;
	while (current != nullptr)
	{
		if (current -> adjacent == &adjacency_list[to_attach_idx])
				found = true;
		current = current -> next;
	}
	return found;
}

//This function is to find the shop location based on the name
//Argument: const string & shop_name
//Return: i for the location 
int table::find_shop_index(const string & shop_name)
{
      for (int i =0; i < num_shop; ++i)
      {
		if (adjacency_list[i].entry != nullptr && adjacency_list[i].entry -> compare(shop_name))
	  		return i;
      }
      return -1;      
}

//This function is to display the vertex list
//Argument: none
//Return: 1/0 for success/failure
int table::display_vertex() const
{
	if (num_shop == 0) return 0;
	else
	{
		cout << "List of vertex:\n";
		display_vertex_recursive(0);
		return 1;
	}
}

//This helper fucntion is to recursive display vertex list
//Argument: int index
//Return: 1/0 for sucess/failure
int table::display_vertex_recursive(int index) const
{
	if (index >= num_shop)
		return 1;
	if (adjacency_list[index].entry != nullptr) 
	{
		adjacency_list[index].entry -> display();
	        cout << "-------------------" << endl;
	}
	return display_vertex_recursive(index + 1);
}

//This function is to display the edge list
//Argument: const string & shop_name
//Return 1/0 for success/failure
int table::display_connected_shops(const string & shop_name)
{
	int current_idx = find_shop_index(shop_name);
	if (current_idx == -1) return 0;
	node * current = adjacency_list[current_idx].head;
        if (!current) return 0; //no connected shop
	cout << "The connected shops to " << shop_name << " are:\n";	
	return display_connected_shops_recursive(current_idx, current); 
}

//This helper is the recursive helper function to display adjacent list
//Argument: int current_idx, node * current) 
//Return: 1/0 for success/failure
int table::display_connected_shops_recursive(int current_idx, node* current)
{
	if (!current) return 0;
	current -> adjacent -> entry -> display();
	cout << "Distance: " << current -> distance << " miles." << endl
	     << "------------------------------" << endl; 
	int result = display_connected_shops_recursive(current_idx, current -> next);
	if (result == 0 && current == adjacency_list[current_idx].head)
		return 0; //no shop
	return 1;
}

//This function is to display the closet shop based on user's input
//Argument: const string & shop_name
//Return: 1/0 for success/failure 
int table::display_closet_shop(const string & shop_name) 
{
	int current_idx = find_shop_index(shop_name);
	if (current_idx == -1) return 0;
	node * current = adjacency_list[current_idx].head;
	if (!current) return 0; //no adjacent shop
	node * closet = current;
        int min_dis = current -> distance;
	while (current)
	{
		if (current -> distance < min_dis)
		{
			min_dis = current -> distance;
			closet = current;
		}
		current = current -> next;
	}
	cout << "The closet shop to " << shop_name << " is:\n"
	     << closet -> adjacent -> entry -> display()
     	     << "\nWith the distance " << min_dis << " miles\n";
 	return 1;
}


