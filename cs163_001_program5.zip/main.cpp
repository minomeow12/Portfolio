//Evelyn Nguyen, CS163 - 001, program#5, 03/14/25
//This main file is to main menu
#include <iostream>
#include <string>
#include "graph.h"   

using namespace std;

int main() 
{
    table ice_cream_graph;   
    shop new_shop;
    int choice;
    string name; 
    string description;
    string location;
    string date_open;
    string current_vertex;
    string to_attach;
    int distance;

    do 
    {
        cout << "\nMenu:\n" 
             << "1. Add a shop\n"
             << "2. Add an edge\n"
	     << "3. Display the vertex list\n"
             << "4. Display the edge list\n"
             << "5. Display the closest\n"
             << "6. Exit\n"
             << "Enter your choice: ";
        cin >> choice;
        cin.ignore(100, '\n');
        switch (choice)
        {
            case 1: //add shop/vertex 
                cout << "\nEnter shop details:\n" 
                     << "Name: ";
                getline(cin, name);  
                cout << "Description: ";
                getline(cin, description);  
                cout << "Location: ";
                getline(cin, location);  
                cout << "Date Opened: ";
                getline(cin, date_open);  
                if (new_shop.create_shop(name, description, location, date_open))
		{
                	if (ice_cream_graph.insert_vertex(new_shop))
				cout << "Shop added successfully!\n";
			else 
				cout << "Error adding! (maybe added already!)\n";
		}
		else
			cout << "Eroor adding!\n";
                break;

            case 2:  //add edge 
                cout << "\nEnter the current shop's name: ";
                getline(cin, current_vertex);  
                cout << "Enter the adjacent shop's name: ";
                getline(cin, to_attach);   
                cout << "Enter the distance between the shops (integer only): ";
                cin >> distance;
                cin.ignore(100, '\n');
                if (ice_cream_graph.insert_edge(current_vertex, to_attach, distance)) 
                    cout << "Edge added successfully!\n";
                else 
                    cout << "Error adding edge.\n";
                break;
	    
            case 3: //display vertex list
		if (ice_cream_graph.display_vertex())
			cout << "Display vertex successfully\n";
		else
			cout << "Error displaying all shop!\n";
		break;

            case 4:  //display edge  list
                cout << "\nEnter the shop's name to display connected shops: ";
                getline(cin, name);   
                if (ice_cream_graph.display_connected_shops(name))  
                    cout << "Connected shops displayed successfully!\n";
                else  
                    cout << "Error displaying connected shops.(maybe having no edge!)\n";
                break;
    
            case 5: //display closest shop
                cout << "\nEnter the shop's name to display the closest shop: ";
                getline(cin, name);   
                if (ice_cream_graph.display_closet_shop(name))
                    cout << "Closet shops displayed successfully!\n";
                else
                    cout << "Error displaying closest shop\n";

            case 6:  // Exit
                cout << "Exiting the program.\n";
                break;

            default:
                cout << "Invalid choice, please try again.\n";
        }

    } while (choice != 6);  

    return 0;
}
