//Evelyn Nguyen, CS163 - 001, program 5, 03/11/2025
//This header file is for the class shop interface

#ifndef SHOP_H
#define SHOP_H 

#include <iostream>
#include <string>
using namespace std;

class shop
{
	public:
		shop();
		~shop();
		int create_shop(const string & name, const string & description, const string & location, const string & date_open);
		int copy_shop(const shop & to_add);
		int retrieve(string name, shop & found);
		int display() const;		
	        bool compare(const string & search_name) const;
		const string& get_name() const;	
	private:
		string name;
		string description;
		string location;
		string date_open;
};

#endif //SHOP_H 
