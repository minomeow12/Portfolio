//Evelyn Nguyen, CS163 - 001, program 5, 03/11/2025
//This header file is for the class graph interface

#ifndef ICE_CREAM_GRAPH_H
#define GRAPH_H
#include "shop.h"

struct vertex
{
	shop * entry;
	struct node * head;
};

struct node
{
	vertex * adjacent;
	int distance;
	node * next;
};

class table
{
	public:
		table(int size = 5);
		~table();
		int insert_vertex(const shop & to_add);
		int insert_edge(const string & current_vertex, const string & to_attach, int distance);
		int find_shop_index(const string & shop_name);
		int display_vertex() const;
		int display_connected_shops(const string & shop_name); //edge list 
		int display_closet_shop(const string & shop_name);   
	private:
		vertex * adjacency_list;
		int num_shop;
		int max_shop;
	        bool edge_exists(int current_idx, int to_attach_idx);
		int display_connected_shops_recursive(int current_idx, node* current);	
		int display_vertex_recursive(int index) const;
};

#endif //GRAPH_H

