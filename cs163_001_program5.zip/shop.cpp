//Evelyn Nguyen, CS163 - 001, program#5, 03/14/25
//This file is to implement the needed functions for shop header file

#include "shop.h" 

//Constructor to initialize
shop::shop()
{
	name = "";
	description = "";
	location = "";
	date_open = "";
}

//Destructor to clean up memory (we use string so there is no work needed)
shop::~shop()
{
}

//This function is to initialize shop info
//Argument: string name, string description,...
//Return: 1/0 for success/failure 
int shop::create_shop(const string & name, const string & description, const string & location, const string & date_open)
{
	if (name.empty() || description.empty() || location.empty() || date_open.empty())
		return 0;
	this -> name = name;
	this -> description = description;
	this -> location = location;
	this -> date_open = date_open;
	return 1;
}

//This function is to copy shop detail into shop object
//Argument: const shop & to_add
//Return 1/0 for success/failure
int shop::copy_shop(const shop & to_add)
{
	this -> name = to_add.name;
	this -> description = to_add.description;
	this -> location = to_add.location;
	this -> date_open = to_add.date_open;
	return 1;
}	

//This function is to retrieve the shop by name
//Argument: strinf name, shop & found
//Return: 1/0 for success/failure
int shop::retrieve(string name, shop & found)
{
	if (this -> name == name)
	{
		found.copy_shop(*this);
		return 1;
	}
	return 0;
}

//This function is to display all the shop
//Argument: none
//Return: 1/0 for success/failure
int shop::display() const
{
	cout << "Shop name: " << name << endl
	     << "Description: " << description << endl
	     << "Location: " << location << endl
	     << "Date opened: " << date_open << endl;
       return 1;
}

//This function is to compare shop name with the input's string
//Argument: const string & search_name
//Return: true/false for success/failure
bool shop::compare(const string & search_name) const
{
	if (name == search_name) return true;
	return false;
}

//This function is helper function to get the name of shop directly
//Argumen: none
//return the name
const string& shop::get_name() const 
{ 
	return name; 
}
