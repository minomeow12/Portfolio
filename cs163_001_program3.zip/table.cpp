//Evelyn Nguyen, CS163 - 001, 02/11/2025, program#3
//This table is to implement the function for the hash table
#include "table.h"
#include <fstream>
#include <sstream>
#include <limits>
using namespace std;

//Constructor
table::table(int size) : hash_table_size(size)
{
    hash_table = new node*[hash_table_size]{};
}

//Destructor
table::~table()
{
    for (int i = 0; i < hash_table_size; ++i)
    {
	    deallocate_chain(hash_table[i]);
    }
    delete[] hash_table;
}

//This helper function is to deallocate memory
void table::deallocate_chain(node *&head)
{
    while (head)
    {
        node *temp = head;
        head = head->next;
        delete temp;
    }
}

//Hash function
//I use djb2 function as searching stack overflow, not sure if it fit the requirement
//Starts with hash = 5381.
//For each character: hash = hash * 33 + character.
//Returns hash % table size to fit in table.
int table::hash_function(const char *id) const
{
    unsigned long hash = 5381;  
    if (id)
    {
        for (int i = 0; id[i] != '\0'; ++i)
       	{
            hash = ((hash << 5) + hash) + static_cast<unsigned char>(id[i]); // hash * 33 + char
        }
    }
    return hash % hash_table_size;  
}

//This function is to insert a new entry in array where the index hash function compute
int table::insert(const char *key, const survey_data &to_add)
{
    int index = hash_function(key);
    node *new_node = new node;
    new_node->entry.copy_entry(to_add);
    new_node->next = hash_table[index];
    hash_table[index] = new_node;
    return 1;
}

//This function is to retrieve an data based on the key
int table::retrieve(const char *key, survey_data &found) const
{
    int index = hash_function(key);  
    node *current = hash_table[index]; 

    while (current)
    { 
        if (current->entry.retrieve(key, found))
       	{ 
            return 1; 
        }
        current = current->next; 
    }
    return 0;  
}

//This function is to display entry by id
int table::display_by_id(const char *id) const
{
    survey_data found;
    return retrieve(id, found) ? found.display() : (cout << "ID not found.\n", 0);
}

//This function is to display all
int table::display_all() const
{
    bool has_data = false;
    for (int i = 0; i < hash_table_size; ++i)
    {
        for (node *current = hash_table[i]; current; current = current->next)
       	{
            current->entry.display();
            has_data = true;
        }
    }
    if (!has_data) cout << "No data available.\n";
    return has_data;
}

//This function is to remove by id
int table::remove_by_id(const char *id)
{
    int index = hash_function(id);
    node *&head = hash_table[index];
    node  *prev = nullptr;
    for (node *current = head; current; prev = current, current = current->next) 
    {
        if (strcmp(current->entry.get_id(), id) == 0)
       	{
            if (prev)
		    prev->next = current->next;
	    else
		    head = current->next;
            delete current;
            cout << "Entry removed.\n";
            return 1;
        }
    }
    cout << "ID not found.\n";
    return 0;
}

//This function is to display by language
int table::display_by_language(const char *language) const
{
    bool found = false;
    for (int i = 0; i < hash_table_size; ++i)
    {
        for (node *current = hash_table[i]; current; current = current->next)
       	{
            if (const char *langs = current->entry.get_languages(); langs && strstr(langs, language))
	    {
                current->entry.display();
                found = true;
            }
        }
    }
    if (!found) cout << "No entries found for language: " << language << "\n";
    return found;
}

