//Evelyn Nguyen, CS163 - 001, 02/11/2025, program#3
//This survey header file is to implement the class for survey data

#ifndef SURVEY_H
#define SURVEY_H

#include <iostream>
#include <cstring>
using namespace std;

class survey_data 
{
public:
    survey_data();
    ~survey_data();

    int create_entry(const char *id, const char *job, const char *age, const char *work_mode, 
                     const char *education_level, const char *learning_source, const char *year_code, 
                     const char *development_type, const char *country, const char *languages, 
                     const char *platforms, const char *personal_os, const char *work_os);

    int copy_entry(const survey_data &new_entry);
    int retrieve(const char *id, survey_data &found) const;
    int display() const;

    const char *get_id() const;
    const char *get_languages() const;

private:
    char *id;
    char *job;
    char *age;
    char *work_mode;
    char *education_level;
    char *learning_source;
    char *year_code;
    char *development_type;
    char *country;
    char *languages;
    char *platforms;
    char *personal_os;
    char *work_os;

    void allocate_and_copy(char *&dest, const char *source);
};

#endif
