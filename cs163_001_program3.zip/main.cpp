//Evelyn Nguyen, CS163, Prog3
//This main file is to read the file
#include "table.h"
#include <fstream>
#include <sstream>
#include <limits>
using namespace std;

void load_data_from_file(table &hash_table, const char *filename)
{
    ifstream file(filename);
    if (!file.is_open())
    {
        cerr << "Error: Cannot open file '" << filename << "'.\n";
        return;
    }

    string line;
    getline(file, line); // Skip header
    while (getline(file, line))
    {
        if (line.empty()) continue;
        stringstream ss(line);
        string fields[13];
        for (int i = 0; i < 13; ++i) {
            getline(ss, fields[i], '|');
            if (fields[i].empty()) fields[i] = "NA";
        }
        survey_data entry;
        entry.create_entry(fields[0].c_str(), fields[1].c_str(), fields[2].c_str(), fields[3].c_str(),
                           fields[4].c_str(), fields[5].c_str(), fields[6].c_str(), fields[7].c_str(),
                           fields[8].c_str(), fields[9].c_str(), fields[10].c_str(), fields[11].c_str(),
                           fields[12].c_str());

        hash_table.insert(fields[0].c_str(), entry);
    }
    cout << "Data loaded from '" << filename << "'.\n";
}

void display_menu() 
{
    cout << "\nProgram Menu"
         << "\n1. Display All"
         << "\n2. Retrieve by ID"
         << "\n3. Remove by ID"
         << "\n4. Display by Language"
         << "\n5. Exit\n"
         << "Select: ";
}

int main() 
{
    table hash_table(17);  
    load_data_from_file(hash_table, "Survey-2024.txt");
    int choice;
    char input[50];
    do {
        display_menu();
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(100, '\n');
            cout << "Invalid input. Please enter a number.\n";
            continue;
        }
        cin.ignore(100, '\n');
        switch (choice)
       	{
            case 1:
                hash_table.display_all();
                break;
            case 2:
                cout << "ID: "; cin.getline(input, 50);
                hash_table.display_by_id(input);
                break;
            case 3:
                cout << "ID to remove: ";
	       	cin.getline(input, 50);
                hash_table.remove_by_id(input);
                break;
            case 4:
                cout << "Language: ";
	       	cin.getline(input, 50);
                hash_table.display_by_language(input);
                break;
            case 5:
                cout << "Quiting the prog!\n";
                break;
            default:
                cout << "Invalid choice.\n";
        }
    } while (choice != 5);

    return 0;
}
