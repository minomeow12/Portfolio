//Evelyn Nguyen, CS163 -001, program3, 02/20/25
//This file is to implement function for survey header file

#include "survey.h"

//Constructor to initialize
survey_data::survey_data()
{
    id = nullptr; job = nullptr; age = nullptr; work_mode = nullptr; education_level = nullptr;
    learning_source = nullptr; year_code = nullptr; development_type = nullptr; country = nullptr;
    languages = nullptr; platforms = nullptr; personal_os = nullptr; work_os = nullptr;
}

//Destructor to deallocate
survey_data::~survey_data()
{
    delete[] id; delete[] job; delete[] age; delete[] work_mode; delete[] education_level;
    delete[] learning_source; delete[] year_code; delete[] development_type; delete[] country;
    delete[] languages; delete[] platforms; delete[] personal_os; delete[] work_os;
}

//This helper function is to allocates memory and copies the contents of 'source' into 'dest' 
void survey_data::allocate_and_copy(char *&dest, const char *source)
{
    delete[] dest;
    if (source && *source) 
    {
        dest = new char[strlen(source) + 1];
        strcpy(dest, source);
    }
    else
    {
        dest = nullptr;
    }
}

//This function is to create entry based on the info we read
int survey_data::create_entry(const char *id_, const char *job_, const char *age_, const char *work_mode_, 
                              const char *education_level_, const char *learning_source_, const char *year_code_, 
                              const char *development_type_, const char *country_, const char *languages_, 
                              const char *platforms_, const char *personal_os_, const char *work_os_)
{
    allocate_and_copy(id, id_); allocate_and_copy(job, job_); allocate_and_copy(age, age_);
    allocate_and_copy(work_mode, work_mode_); allocate_and_copy(education_level, education_level_);
    allocate_and_copy(learning_source, learning_source_); allocate_and_copy(year_code, year_code_);
    allocate_and_copy(development_type, development_type_); allocate_and_copy(country, country_);
    allocate_and_copy(languages, languages_); allocate_and_copy(platforms, platforms_);
    allocate_and_copy(personal_os, personal_os_); allocate_and_copy(work_os, work_os_);
    return 1;
}

//This function is to copy the info to the object
int survey_data::copy_entry(const survey_data &new_entry)
{
    return create_entry(new_entry.id, new_entry.job, new_entry.age, new_entry.work_mode,
                        new_entry.education_level, new_entry.learning_source, new_entry.year_code,
                        new_entry.development_type, new_entry.country, new_entry.languages,
                        new_entry.platforms, new_entry.personal_os, new_entry.work_os);
}

//This function is to retrieve entry based on the ID
int survey_data::retrieve(const char *search_id, survey_data &found) const
{
       if (id != nullptr && search_id != nullptr)
       {
		if (strcmp(id, search_id) ==0)
	 		return found.copy_entry(*this);
       }
       return 0;       
}

//This function is to display all the entry
int survey_data::display() const
{
    cout << "------------------------\n"
         << "ID: " << (id ? id : "NA") << "\n"
         << "Job: " << (job ? job : "NA") << "\n"
         << "Age: " << (age ? age : "NA") << "\n"
         << "Mode: " << (work_mode ? work_mode : "NA") << "\n"
         << "Education: " << (education_level ? education_level : "NA") << "\n"
         << "Learn Source: " << (learning_source ? learning_source : "NA") << "\n"
         << "Years Code: " << (year_code ? year_code : "NA") << "\n"
         << "Dev Type: " << (development_type ? development_type : "NA") << "\n"
         << "Country: " << (country ? country : "NA") << "\n"
         << "Languages: " << (languages ? languages : "NA") << "\n"
         << "Platforms: " << (platforms ? platforms : "NA") << "\n"
         << "Personal OS: " << (personal_os ? personal_os : "NA") << "\n"
         << "Work OS: " << (work_os ? work_os : "NA") << "\n"
         << "------------------------\n";
    return 1;
}

//These function is to get id (for hash table)
const char *survey_data::get_id() const { return id; }
const char *survey_data::get_languages() const { return languages; }
