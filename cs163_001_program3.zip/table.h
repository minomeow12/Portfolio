//Evelyn Nguyen, CS163 - 001, 02/11/2025, program#3
//This table header file is to implement the class for the hash table
#ifndef TABLE_H
#define TABLE_H

#include "survey.h"

struct node {
    survey_data entry;
    node *next;
};

class table {
public:
    table(int size = 11);
    ~table();

    int hash_function(const char *id) const;
    int insert(const char *key, const survey_data &to_add);
    int retrieve(const char *key, survey_data &found) const;
    int display_by_id(const char *id) const;
    int display_all() const;
    int remove_by_id(const char *id);
    int display_by_language(const char *language) const;

private:
    node **hash_table;
    int hash_table_size;
    void deallocate_chain(node *&head);
};

#endif

