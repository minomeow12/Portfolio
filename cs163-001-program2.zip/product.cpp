//Eveleyn Nguyen, CS163 -001, 01/31/2025, program #2
//This cpp file is to implement the functions for product header file

#include "product.h"
using namespace std;

//constructor
product::product()
{
	name = nullptr;
	category = nullptr;
	expiration_date = nullptr;
	price = 0.0;
	calories = 0;
	sold_date = nullptr;
	buyer = nullptr;
	shelf_number = 0;
}

//Destructor
product::~product()
{
	delete[] name;
	delete[] category;
	delete[] expiration_date;
	delete[] sold_date;
	delete[] buyer;
}

//This function is to create a product with these needed atributes
//Argument: all the attributes of an item for stack 
//Return: 1 if success
int product::create_stack(char * name, char * category, char * expiration_date, float price, int calories)
{
    delete[] this->name;
    delete[] this->category;
    delete[] this->expiration_date;

    this->name = new char[strlen(name) + 1];
    strcpy(this->name, name);
    this->category = new char[strlen(category) + 1];
    strcpy(this->category, category);
    this->expiration_date = new char[strlen(expiration_date) + 1];
    strcpy(this->expiration_date, expiration_date);
    this->price = price;
    this->calories = calories;
    return 1;   
}

//This function is to create a product with these needed atributes
//Argument: all the attributes of an item for queue 
//Return: 1 if success
int product::create_queue(char * name, char * category, char * expiration_date, float price, int calories, char * sold_date, char * buyer, int shelf_number)
{
    delete[] this->sold_date;
    delete[] this->buyer;
    if (name != nullptr) {
        this->name = new char[strlen(name) + 1];
        strcpy(this->name, name);
    } else {
        this->name = nullptr;   
    }
    if (category != nullptr) {
        this->category = new char[strlen(category) + 1];
        strcpy(this->category, category);
    } else {
        this->category = nullptr;  
    }
    if (expiration_date!= nullptr) {
        this->expiration_date = new char[strlen(expiration_date) + 1];
        strcpy(this->expiration_date, expiration_date);
    } else {
        this->expiration_date = nullptr;   
    }
    this -> price = price;
    this -> calories = calories; 
    if (sold_date != nullptr) {
        this->sold_date = new char[strlen(sold_date) + 1];
        strcpy(this->sold_date, sold_date);
    } else {
        this->sold_date = nullptr;   
    }
    if (buyer != nullptr) {
        this->buyer = new char[strlen(buyer) + 1];
        strcpy(this->buyer, buyer);
    } else {
        this->buyer = nullptr;  
    }
    this->shelf_number = shelf_number;
    return 1;  
}

//This function is to copy data to a new object for stack 
//Argument: const product & new_product
//Return: 1 if success
int product::copy_stack(const product & new_product)
{
    if (this == &new_product) return 0;
    return create_stack(new_product.name, new_product.category, new_product.expiration_date, new_product.price, new_product.calories);
}

//This function is to copy data to a new object for queue 
//Argument: const product & new_product
//Return: 1 if success
int product::copy_queue(const product & sold_product)
{
    if (this == &sold_product) return 0;
    return create_queue(sold_product.name, sold_product.category, sold_product.expiration_date, sold_product.price, sold_product.calories, sold_product.buyer, sold_product.sold_date, sold_product.shelf_number); 
}

//This function is to display product
//Argument: none
//Return: true if success
bool product::display() const
{
    if (name && category && expiration_date)
    {
        cout << "Product Name: " << name << endl
             << "Category: " << category << endl
             << "Expiration date: " << expiration_date << endl
             << "Price: " << price << endl
             << "Calories: " << calories << endl;
        return true;
    }
    else if (sold_date && buyer && shelf_number != 0) 
    {
        cout << "Sold date: " << sold_date << endl
             << "Buyer: " << buyer << endl
             << "Shelf number: " << shelf_number << endl;
        return true;
    }
    return false;
}

