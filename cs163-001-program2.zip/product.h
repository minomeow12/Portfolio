//Evelyn Nguyen, CS163-001, 01/31/2025, program#2
//This product header file is to create a class for product

#include <iostream>
#include <cstring>
#include <cctype>
#ifndef PRODUCT_H  
#define PRODUCT_H   
class product
{
	public:
		product();
		~product();
		int create_stack(char * name, char * category, char * expiration_date, float price, int calories);
		int create_queue(char * name, char * category, char * expiration_date, float price, int calories, char * sold_date, char * buyer, int shelf_number);
	        int copy_stack(const product & new_product);
	        int copy_queue(const product & sold_product);	
		bool display() const;
	private:
		char * name;
		char * category;
		char * expiration_date;
		float price;
		int calories; 
		char * sold_date;
		char * buyer;
		int shelf_number;
};
#endif   
