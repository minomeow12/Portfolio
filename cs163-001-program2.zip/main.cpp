//Evelyn Nguyen, CS163-001, 2/4/2025, program#2
//This main file is to test all the functions
#include "stack.h"
#include "queue.h"
#include "menu.h"
#include "product.h"
using namespace std;

int main() 
{
    queue my_queue;  
    stack my_stack; 
    int choice;  
    int data_choice; 
    int exit_choice = 0;  

    do 
    {
        cout << "Which data structure?: ";
        cout << "1. Queue\n";
        cout << "2. Stack\n";
        cout << "3. Exit\n";  
        cout << "Enter your choice: ";
        cin >> data_choice;
        cin.ignore(100, '\n');  

        if (data_choice == 1) 
        {
            do 
            {
                display_qenu();
                cin >> choice;
                cin.ignore(100, '\n'); 

                if (choice == 1) 
                {
                    enqueue(my_queue);  
                } 
                else if (choice == 2) 
                {
                    dequeue(my_queue);  
                } 
                else if (choice == 3) 
                {
                    peek_q(my_queue);  
                } 
                else if (choice == 4) 
                {
                    display_q(my_queue); 
                } 
                else if (choice == 5) 
                {
                    break;  
                } 
                else 
                {
                    cout << "Invalid choice. Please try again." << endl;
                }

                cout << "Do you want to perform another operation on the queue? (1 = Yes, 2 = No): ";
                cin >> exit_choice;
                cin.ignore(100, '\n');  

            } while (exit_choice == 1);  
        } 
        else if (data_choice == 2) 
        {
            do 
            {
                display_senu();
                cin >> choice;
                cin.ignore(100, '\n');  

                if (choice == 1) 
                {
                    push(my_stack); 
                } 
                else if (choice == 2) 
                {
                    pop(my_stack); 
                } 
                else if (choice == 3) 
                {
                    peek_s(my_stack); 
                } 
                else if (choice == 4) 
                {
                    display_s(my_stack); 
                } 
                else if (choice == 5) 
                {
                    break;  
                } 
                else 
                {
                    cout << "Invalid choice. Please try again." << endl;
                }

                cout << "Do you want to perform another operation on the stack? (1 = Yes, 2 = No): ";
                cin >> exit_choice;
                cin.ignore(100, '\n');  

            } while (exit_choice == 1);  
        } 
        else if (data_choice == 3) 
        {
            cout << "Exiting program." << endl;
            exit_choice = 1; 
        } 
        else 
        {
            cout << "Invalid choice. Please try again." << endl;
        }

    } while (exit_choice == 0);  
    
    return 0;
}
