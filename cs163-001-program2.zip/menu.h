
//Evelyn Nguyen, 02/07/2025, CS163, prog2
//This menu header file is the prototype for menu  
#ifndef MENU_H
#define MENU_H

#include "queue.h"
#include "stack.h"
#include "product.h"

//Prototype
void display_senu();
void display_qenu();
void push(stack &s);
void pop(stack &s);
void peek_s(stack &s);
void display_s(stack &s);
void enqueue(queue &q);
void dequeue(queue &q);
void peek_q(queue &q);
void display_q(queue &q);
#endif  
