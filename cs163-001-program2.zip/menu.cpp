//Evelyn Nguyen, CS163, program2, 02/07
//This file to is to implemement menu function

#include <iostream>
#include "menu.h"

using namespace std;


void display_senu() 
{
    cout << "Stack Menu:" << endl
         << "1. Push" << endl
         << "2. Pop" << endl
         << "3.Peek" << endl
         << "4.Display" << endl
         << "5. Back to main" << endl
         << "What your choice: "; 
}

void display_qenu() 
{
    cout << "Queue Menu:" << endl
         << "1. Enqueue" << endl
         << "2. Dequeue" << endl
         << "3.Peek" << endl
         << "4.Display" << endl
         << "5. Back to main menu" << endl
         << "What your choice: ";
}

void push(stack &s) 
{
    char name[50], category[50], expiration_date[50];
    float price;
    int calories;
    cout << "Enter product name: ";
    cin.ignore();
    cin.getline(name, 50);
    cout << "Enter product category: ";
    cin.getline(category, 50);
    cout << "Enter expiration date: ";
    cin.getline(expiration_date, 50);
    cout << "Enter price: ";
    cin >> price;
    cout << "Enter calories: ";
    cin >> calories;
    product new_product;
    new_product.create_stack(name, category, expiration_date, price, calories);
    if (s.push(new_product))
    {
        cout << "Product pushed onto the stack successfully!" << endl;
    }
    else
    {
        cout << "Failed to push product onto the stack!" << endl;
    }
}

void pop(stack &s) 
{
    product removed_product;
    if (s.pop(removed_product)) 
    { 
        cout << "Product popped from the stack successfully!" << endl;
    } 
    else 
    {
        cout << "Stack is empty. Cannot pop." << endl;
    }
}

void peek_s(stack &s) 
{
    product top_product;
    if (s.peek(top_product))
    {
        cout << "Top product on the stack:" << endl;
        top_product.display();
    }
    else
    {
        cout << "Stack is empty. Nothing to peek." << endl;
    }
}

void display_s(stack &s) 
{
    if (!s.display())
    {
        cout << "Stack is empty." << endl;
    }
}

void enqueue(queue &q) 
{
    char name[50], category[50], expiration_date[50], sold_date[50], buyer[50];
    float price;
    int calories, shelf_number;

    cout << "Enter product name: ";
    cin.ignore();
    cin.getline(name, 50);
    cout << "Enter product category: ";
    cin.getline(category, 50);
    cout << "Enter expiration date: ";
    cin.getline(expiration_date, 50);
    cout << "Enter price: ";
    cin >> price;
    cout << "Enter calories: ";
    cin >> calories;
    cout << "Enter sold date: ";
    cin.ignore();
    cin.getline(sold_date, 50);
    cout << "Enter buyer name: ";
    cin.getline(buyer, 50);
    cout << "Enter shelf number: ";
    cin >> shelf_number;
    cin.ignore(); 
    product new_product;
    new_product.create_queue(name, category, expiration_date, price, calories, sold_date, buyer, shelf_number);
    if (q.enqueue(new_product))
    {
        cout << "Product enqueued successfully!" << endl;
    }
    else
    {
        cout << "Failed to enqueue product!" << endl;
    }
}

void dequeue(queue &q) 
{
    product removed_product;
    if (q.dequeue(removed_product))
    {
        cout << "Product dequeued successfully!" << endl;
        removed_product.display();
    } 
    else
    {
        cout << "Queue is empty. Cannot dequeue." << endl;
    }
}

void peek_q(queue &q) 
{
    product next_sold;
    if (q.peek(next_sold))
    {
        cout << "Next product to be sold:" << endl;
        next_sold.display();
    }
    else
    {
        cout << "Queue is empty. Nothing to peek." << endl;
    }
}

void display_q(queue &q) 
{
    if (!q.display())
    {
        cout << "Queue is empty." << endl;
    }
}
