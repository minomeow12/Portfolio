
//Evelyn Nguyen, CS163-001, 01/29/2025, program#2
//This queue header file is for the queue class and structs 
#ifndef STACK_H
#define STACK_H
#include "product.h" 

//Node structure for Queue (CLL)
struct q_node
{
	product sold_item;
	q_node * next;
};

//Queue Class
class queue
{
	public:
		queue();
		~queue();
		bool enqueue(const product & to_add);
		bool dequeue(product & to_remove);
		bool peek(product & next_sold) const;
		bool display() const;
	private:
		q_node * rear;
	        void delete_nodes(q_node * current);	
};
#endif
