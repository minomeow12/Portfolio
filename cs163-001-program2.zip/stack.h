//Evelyn Nguyen, CS163-001, 01/29/2025, program#2
//This stack header file is for the stack class and structs 
#ifndef QUEUE_H
#define QUEUE_H
#include "product.h" 

//Node structure for Stack (LLL)
struct s_node
{
	product * products;
	s_node * next;
};

//Create array of const size MAX
const int MAX = 5;

//Stack Class
class stack
{
	public:
		stack();
		~stack();
		bool display() const;
		bool push(const product & new_item);
		bool pop(product & removed_item);
		bool peek(product & top_product) const; 
	private:
		s_node * head;
		int top_index;
};
#endif
