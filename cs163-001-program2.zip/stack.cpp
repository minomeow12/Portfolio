//Evelyn Nguyen, CS163-001, 01/31/25, program#2
//This cpp file is to implement needded functions for stack.h

#include "stack.h"

//Constructor
stack::stack()
{
	head = nullptr;
	top_index = 0;
}

//Destructor
stack::~stack()
{
	while (head)
	{
		s_node * temp = head;
		head = head -> next;
		for (int i =0; i< MAX; ++i)
		{
			temp -> products[i].~product();
		}
		delete[] temp -> products;
		delete temp;
	}
}	

//This function is to push item
//Argument:const Product & new_item
//Return: true if success
bool stack::push(const product & new_item)
{
	if (!head || top_index == MAX)
	{
		s_node * new_node = new s_node;
		new_node -> products = new product[MAX];
		new_node -> next = head;
		head = new_node;
		top_index = 0;
	}
	if (!head -> products[top_index].copy_stack(new_item))
		return false;
	++ top_index;
	return true; 
}

//This function is to pop item
//Argument: Product & removed_item
//Return: true if success
bool stack::pop(product & removed_item)
{
	if (!head || top_index ==0) return false;
	-- top_index;
	if(top_index == 0 && head -> next)
	{
		s_node * temp = head;
		head = head -> next;
		delete temp -> products;
		delete temp;
		top_index = MAX;
	}
	return true;
}

//This function is to peek at the top product without it
//Argument: product & top_product
//Return: true if success
bool stack::peek(product & top_product) const 
{
	if (!head || top_index == MAX) return false;
	return top_product.copy_stack(head -> products[top_index-1]);
}

//This function is to display the product
//Argument: none
//Return: none
bool stack::display() const
{
	if (!head) return false;
	s_node * current = head;
	int current_top = top_index;
	while (current)
	{
		for (int i = current_top -1; i>=0; --i)
		{
			current -> products[i].display();
		}
		current = current -> next;
		current_top = MAX; 
	}
	return true;
}

