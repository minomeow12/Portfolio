//Evelyn Nguyen, CS163 -001, 2/4/2025, program#2
//This file is to implement function of queue

#include "queue.h"

//Constructor
queue::queue()
{
	rear = nullptr;
}

//Destructor
queue::~queue()
{
    if (!rear) return;  
    delete_nodes(rear->next);  
    rear = nullptr; 
}
void queue::delete_nodes(q_node *current)
{
    if (current == rear->next) return;
    q_node *temp = current;
    current = current->next;  
    delete temp;
    delete_nodes(current); 
}

//This function is to enqueue to product purchased
//Argument: product & sold_item
//Return: true if success
bool queue::enqueue(const product & to_add)
{
	q_node * new_node = new q_node;
	if (!new_node -> sold_item.copy_queue(to_add))
	{
		delete new_node;
		return false;
	}
	if (!rear)
	{
		rear = new_node;
		rear -> next = rear;
		return true;
	}
       	new_node -> next =  rear -> next;
	rear -> next = new_node;
	rear = new_node;
	return true;
}

//This function is to display all the product purchased
//Argument: none
//Return: true if success
bool queue::display() const
{
	if (!rear) return false;
	q_node * current = rear -> next;
	do
	{
		current -> sold_item.display();
		current = current -> next;
	}
	while (current != rear -> next);
	return true;
}

//This function is to dequeue 
//Argument: product & to_remove
//return: true if success
bool queue::dequeue(product & to_remove) 
{
	if (!rear) return false;
	q_node * front = this -> rear -> next;
	if (front == rear)
	{
		delete front;
		rear = nullptr;
		return true;
	}
	rear -> next = front -> next;
	delete front;
	return true;
}
	
//This function is to peek the product sold next
//Argument: product & next_sold
//Return: true if success
bool queue::peek(product & next_sold) const
{
	if (!rear) return false;
	q_node * front = this -> rear -> next;
	next_sold = front -> sold_item;
        return true;	
}


