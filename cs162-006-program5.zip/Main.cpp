#include "Games.h"

//Evelyn Nguyen, evelynng@pdx.edu, CS162 - section 006, program 5, 12/05/2024
//This code is the core of the program

//Prototype for menu options and hanlde menu
int show_menu_options();
void handle_menu_options(int menu_response, node * & head);


int main()
{
	//Create variable
	node * head = nullptr;
	int menu_response{0};
	cout << "Welcome to the Game List Program!\n";

	//Call the function
	do
	{
		menu_response = show_menu_options();
		handle_menu_options(menu_response, head);
	}
	while (menu_response != 4);

	//we still need to include display_menu() and handle_menu_option()

	cout << "Quitting...\n";
	return 0;
}

//This function is to provide menu interface for user to select their choice
//No argument
//Return an integer based on their choice
int show_menu_options()
{
	int menu_response;
	cout << "In this program, we have these options. Please enter a number for your choice.\n"
	     << "1.Insert a game\n"
	     << "2.Display all games\n"
	     << "3.Display games by type\n"
	     << "4.Quit\n"
	     << "Which one you gonna choose: ";

	while (!(cin >> menu_response) || menu_response < 1 || menu_response > 4)
	{
		cin.clear();
		cin.ignore(100, '\n');
		cout << "Invalid choice! Please choose 1-4 only!\n";
	}

	cin.ignore(100, '\n');

	return menu_response;
}

//This function is to handle user response for menu
//Arguments: int menu_response, List & item_list
//No return value
void handle_menu_options(int menu_response, node * &head)
{
	if (menu_response ==1)
		insert_sorted(head);
	else if (menu_response ==2)
		display_games(head);
	else if (menu_response == 3)
		display_by_type(head);
	else if (menu_response ==4)
		cout << "Quit the program\n";
	else
		cout << "Invalid choice\n";
}

