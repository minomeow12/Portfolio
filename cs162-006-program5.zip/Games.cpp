#include "Games.h"

//Evelyn Nguyen, evelynng@pdx.edu, CS162 - section 006, program#5, 12/5/2024
//This code is to implement the needed functions

//This function is to read in the game's info
//Argument: Node* new_node
//Return: none
void read_game_info(node * new_node)
{
	char temp_name[50];
	cout << "Please enter the game's name: ";
	cin.get(temp_name, 50, '\n');
	cin.ignore(100, '\n');
	new_node -> name = new char[strlen(temp_name) +1];
	strcpy(new_node -> name, temp_name);

	cout << "Please enter the description: ";
	cin.get(new_node -> description, 100, '\n');
	cin.ignore(100, '\n');

	cout << "Please enter the maxium players: ";
	cin >> new_node ->  max_players;
	cin.ignore(100, '\n');

	cout << "Please enter the type: ";
	cin.get(new_node -> type, 20, '\n');
	cin.ignore(100, '\n');

	cout << "Please enter the maxium time: ";
	cin.get(new_node -> max_time, 20, '\n');
	cin.ignore(100, '\n');

	new_node -> next = nullptr;
}

//This function is to insert a node at the beginning of the list and sort it alphabetically
//Argument: Node* & head
//Return: none
void insert_sorted(node * & head)
{
	node* new_node = new node;
	read_game_info(new_node);
	//empty list or the recently added name is appear first in alphabetically order
	if (!head || strcmp(new_node -> name, head->name)<0)
	{
		new_node -> next = head;
		head = new_node;
		return;
	}

	//traverse to find the correct position to insert
	node * previous {head};
	node * current{head-> next};
	while (current && strcmp(new_node -> name, current -> name) > 0)
	{
		previous = current;
		current = current -> next;
	}
	new_node -> next = current;
	previous -> next = new_node;
}

//This function is to append an item at the end of the list **i'm trying to do recursive
//Argument: Node* &head
//Return: none
void append_at_end(node* & head)
{
	if (!head)
	{
		head = new node;
		read_game_info(head);
		head -> next = nullptr;
		return;
	}
	append_at_end(head->next);
}

//This function is to display all the games
//Argument: Node* head
//Return: none
void display_games(node* head)
{
	node * temp{head};
	while (temp != nullptr)
	{
		cout << "Name: " << temp -> name << endl
		     << "Description: " << temp -> description << endl
		     << "Maximum players: " << temp -> max_players << endl
		     << "Type: " << temp -> type << endl
		     << "Maximum time: " << temp -> max_time << endl;
		temp = temp -> next;
	}
}

//This function is to display the game matched with the type users enter
//Argument: node * head
//Return: none
void display_by_type(node * head)
{
	char temp_type[20];
	cout << "Please enter the type of the game you're looking for: ";
	cin.get(temp_type, 20, '\n');
	cin.ignore(100, '\n');

	bool found = false;
	node * hold{head};
	while (hold != nullptr)
	{
		if (strcmp(hold->type, temp_type) == 0)
		{
			cout << "We found this!" << endl
			     << "Name: " << hold -> name << endl
			     << "Description: " << hold -> description << endl
			     << "Maximum players: " << hold -> max_players << endl
			     << "Type: " << hold -> type << endl
			     << "Maximum time: " << hold -> max_time << endl;
			found = true;
		}
		hold = hold -> next;
	}
	if (!found)
		cout << "There is no game matched the type you're looking for." << endl;
}


//This function is to to destroy the list to realse dynamic memory
//Argument: node * & head
//Return: none
void destroy_list(node * & head)
{
	if (!head)
		return;
	node * hold = head -> next;
	delete head;
	head = hold;
	destroy_list(head);
}


