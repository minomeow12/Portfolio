#include <iostream>
#include <cctype>
#include <cstring>
using namespace std;

//Evelyn Nguyen, evelynng@pdx.edu, CS162 section 006. program 5, 12/5/2024
//This code is going manage how we work with games and linear linked list

//The data structure is a linear linked list of games information
struct node
{
	char * name;
	char description[100];
	int max_players{0};
	char type[20];
	char max_time[20];
	node * next;

	//constructor and destructor for dynamically memory
	node()
	{
		name = nullptr;
	}
	~node() 
	{
		delete[] name;
	}
};

//Proctotype
void read_game_info(node* new_node);
void insert_sorted(node* &head);
void append_at_end(node* &head);
void display_games(node* head);
void display_by_type(node * head);
void destroy_list(node * & head);
