#include "Items.h"


//Evelyn Nguyen, evelynng@pdx.edu, CS162 - section 006, program 4, 11/21/2024
//The purpose of this file is a basic structure of the program

//Prototype for menu options and hanlde menu
int show_menu_options();
void handle_menu_options(int menu_response, List &item_list);


int main()
{
	//Create variable
	List my_list;	
	int menu_response;

	//Call the function
	do
	{
		menu_response = show_menu_options();
		handle_menu_options(menu_response, my_list);
	}
	while (menu_response != 5);

	//we still need to include display_menu() and handle_menu_option()

	cout << "Quitting...\n";
	return 0;
}

//This function is to provide menu interface for user to select their choice
//No argument
//Return an integer based on their choice
int show_menu_options()
{
	int menu_response;
	cout << "In this program, we have these options. Please enter a number for your choice.\n"
	     << "1.Enter a new item for sale\n"
	     << "2.Display all items\n"
	     << "3.Display items by name\n"
	     << "4.Display item by seller name\n"
	     << "5.Quit\n"
	     << "Which one you gonna choose: ";

	while (!(cin >> menu_response) || menu_response < 1 || menu_response > 5)
	{
		cin.clear();
		cin.ignore(100, '\n');
		cout << "Invalid choice! Please choose 1-6 only!\n";
	}

	cin.ignore(100, '\n');

	return menu_response;
}

//This function is to handle user response for menu
//Arguments: int menu_response, List & item_list
//No return value
void handle_menu_options(int menu_response, List & item_list)
{
	if (menu_response ==1)
		item_list.read_item();
	else if (menu_response ==2)
		item_list.display_items();
	else if (menu_response == 3)
		item_list.display_by_name();
	else if (menu_response == 4)
		item_list.display_by_seller_name();
	else if (menu_response ==5)
		cout << "Quit the program\n";
	else
		cout << "Invalid choice\n";
}

