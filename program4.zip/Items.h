#include <iostream>
#include <cctype>
#include <cstring>
using namespace std;

//Evelyn Nguyen, evelyng@pdx.edu, CS162 section 006. program 4, 11/21/2024
//This code is going manage how we work with items

const int NAME {50};
const int ID {20};
const int CATEGORY {30};
const int DESCR {200};
const int SERIES {30};
const int CONDITION {20};

//Structure store the item information
struct Item
{
	char item_name[NAME];
	char id[ID];
	char category[CATEGORY];
	char descript[DESCR];
	char series[SERIES];
	char condition[CONDITION];
	float price;
	char seller_name[NAME];
	bool sold;
};

//Class interface for list
class List
{
	public:
		List();
		~List();
		void read_item();
		void add_item(const Item & new_item);
		void resize();
		void display_items();
		void display_by_name();
		void display_by_seller_name();
	private:
		Item* items;
		int size;
		int num_items;
};

