#include "Items.h"

//Evelyn Nguyen, evelynng@pdx.edu, CS162 - section 006, program 4, 1/12/2024
//The purpose of this file is to implement the member functions
//provided in the List class
//
//The data members are:
/*
        Item * items
        int size;
        int num_items;
*/

//This is the List constructor and it should initialize all of the
//data members in the List class
List::List()
{
	size =20;
	num_items = 0;
	items = new Item[size];
}

//Destructor to release the data
List::~List()
{
	delete[] items;
}

//This function is to read in the item's detail
//No arguments
//No return value
void List::read_item() {
    Item new_item;

    // Read item name
    cout << "Please enter the item's name: ";
    cin.getline(new_item.item_name, NAME);  

    // Read item ID
    cout << "Please enter the ID: ";
    cin.getline(new_item.id, ID);  

    // Read category
    cout << "Please enter the category: ";
    cin.getline(new_item.category, CATEGORY);  

    // Read description
    cout << "Please enter the description: ";
    cin.getline(new_item.descript, DESCR);  

    // Read series
    cout << "Please enter the series: ";
    cin.getline(new_item.series, SERIES);  

    // Read condition
    cout << "Please enter the condition: ";
    cin.getline(new_item.condition, CONDITION);  

    // Read price
    cout << "Please enter the price: ";
    cin >> new_item.price;
    cin.ignore(100, '\n'); 

    // Read seller's name
    cout << "Please enter the seller's name: ";
    cin.getline(new_item.seller_name, NAME);  

    // Read sold status
    char sold_status;
    cout << "Is it sold? (y/n only): ";
    cin >> sold_status;
    cin.ignore(100, '\n');
    new_item.sold = (tolower(sold_status) == 'y');  

    add_item(new_item);  // Add the item to the list
}
//This funtion is to allow user add item
//Argument: const Item & new_item
//No return value
void List::add_item(const Item & new_item)
{
	if (size == num_items)
		resize();
	items[num_items] = new_item;
	num_items ++;
}

//This function is to resize the array when its full
//No argument
//No return value
void List::resize()
{
	int new_size = size * 2;
	Item* new_item = new Item[new_size];
	for (int i =0; i < size; ++i)
	{
		new_item[i] = items[i];
	}
	delete[] items;
	items = new_item;
	size = new_size;
}

//This funtion is to display all the items in the list
//No arguments
//No return value
void List::display_items() {
    if (num_items == 0)
    {
        cout << "No items in the list \n";
        return;
    }

        // Display the item details
    for (int i=0; i < num_items; ++i)
    {
        cout << "Item " << i + 1 << endl
             << "Name: " << items[i].item_name << endl
             << "ID: " << items[i].id << endl
             << "Description: " << items[i].descript << endl
             << "Category: " << items[i].category << endl
             << "Condition: " << items[i].condition << endl
             << "Series: " << items[i].series << endl
             << "Price: " << items[i].price << endl
             << "Seller name: " << items[i].seller_name << endl
             << "Sold status: " << (items[i].sold ? "Yes" : "No") << endl
             << "____________________" << endl;
    }
}
//This function is to let user search for the item by name and if match, display it
//No arguments
//No return value
void List::display_by_name()
{
	char search_name[NAME];
	cout <<"Please enter a name of the item you want to display: ";
	cin.get(search_name, NAME, '\n');
	cin.ignore(100, '\n');
	bool found = false;

	if (num_items ==0)
	{
		cout << "There is no items in the list\n";
		return;
	}

	for (int i =0; i < num_items; ++i)
	{
		if (strcasecmp(search_name, items[i].item_name) ==0)
		{
			cout << "Here is the detail of the item you're looking for:\n"
			     << "Name: " << items[i].item_name << endl
			     << "ID: " << items[i].id << endl
			     << "Category: " << items[i].category << endl
			     << "Description: " << items[i].descript << endl
			     << "Condition: " << items[i].condition << endl
			     << "Series: " << items[i].series << endl
			     << "Price: " << items[i].price << endl
			     << "Seller name: " << items[i].seller_name << endl
			     << "Sold status: " << (items[i].sold? "Yes" : "No") << endl;
			found = true;
			break;
		}
	}

	if (!found)
		cout << "There is no match!\n";


}

//This function is to let user search the item by seller name, and if match, display it
//No arguments
//No return value
void List::display_by_seller_name()
{

	char search_name[NAME];
	cout <<"Please enter a seller's name of the item you want to display: ";
	cin.get(search_name, NAME, '\n');
	cin.ignore(100, '\n');
	bool found = false;

	if (num_items ==0)
	{
		cout << "There is no items in the list\n";
		return;
	}

	for (int i =0; i < num_items; ++i)
	{
		if (strcasecmp(search_name, items[i].seller_name) ==0)
		{
			cout << "Here is the detail of the item you're looking for:\n"
			     << "Name: " << items[i].item_name << endl
			     << "ID: " << items[i].id << endl
			     << "Category: " << items[i].category << endl
			     << "Description: " << items[i].descript << endl
			     << "Condition: " << items[i].condition << endl
			     << "Series: " << items[i].series << endl
			     << "Price: " << items[i].price << endl
			     << "Seller name: " << items[i].seller_name << endl
			     << "Sold status: " << (items[i].sold? "Yes" : "No") << endl;
			found = true;
			break;
		}
	}

	if (!found)
		cout << "There is no match!\n";
}

